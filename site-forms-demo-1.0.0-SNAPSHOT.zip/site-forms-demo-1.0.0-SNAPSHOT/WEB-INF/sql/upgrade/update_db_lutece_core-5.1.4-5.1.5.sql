CREATE INDEX core_admin_user_field_idx_file on core_admin_user_field (id_file);
