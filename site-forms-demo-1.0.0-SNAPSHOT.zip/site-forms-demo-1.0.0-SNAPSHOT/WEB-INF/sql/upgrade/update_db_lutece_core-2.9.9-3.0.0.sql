--
-- Dumping data into table core_user_parameter
--
INSERT INTO core_user_parameter VALUES ('email_pattern', '^[\\w_.\\-]+@[\\w_.\\-]+\\.[\\w]+$');
INSERT INTO core_user_parameter VALUES ('email_pattern_verify_by', '');
