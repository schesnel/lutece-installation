ALTER TABLE core_admin_right ADD COLUMN documentation_url varchar(255) DEFAULT NULL;
ALTER TABLE core_admin_right ADD COLUMN id_order int(11) DEFAULT NULL;