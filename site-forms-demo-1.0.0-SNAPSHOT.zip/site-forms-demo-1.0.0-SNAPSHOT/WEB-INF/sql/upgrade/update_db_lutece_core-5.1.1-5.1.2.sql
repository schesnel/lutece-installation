ALTER TABLE core_admin_right MODIFY COLUMN is_external_feature SMALLINT default 0;
