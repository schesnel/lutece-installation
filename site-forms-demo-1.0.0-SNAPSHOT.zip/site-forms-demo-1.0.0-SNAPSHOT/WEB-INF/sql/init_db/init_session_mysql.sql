SET default_storage_engine = MyISAM;
